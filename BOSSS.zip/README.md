# <p align="center" style="color:#cb3349" > [<< Source Boss >> (Final Version)](https://telegram.me/F5z123)

<p align="center" style="color: #14635c;" > سورس لوست الاقوى والاحدث لحماية المجموعات في التليقرام

***

# <p align="center" style="color: #14635c;" > [التنصيب بكود واحد](https://t.me/F5z123)
```sh
git clone https://github.com/z73v/LOSST.git ;cd LOSST;chmod +x ins;./ins
```
```
» فقط أضغط على الكود ☝️ وقم بنسخه
» ثم الصقه بالترمنال وانتر تتنظر يتنصب 
» بعدهہ‌‏آ يطـلب مـعلومـآت بآلترمـنآل .
» تدخل مـعلومـآتگ مـن توگن ومـعرفگ 
» وسـوف يعمـل آلبوت بالسـگرين تلقآئيآ ...
```
# <p align="center" style="color: #14635c;" > [كود الرون](https://t.me/F5z123)
```sh
./UserBot/run

Example

./@LOSSTBOT/run
```
# <p align="center" style="color: #14635c;" >  [لتغيير المطور الاساسي ](https://t.me/F5z123)
```sh
ارسل للبوت : نقل ملكيه البوت
```
[3z](https://t.me/z7cz9)

[Source developer](https://t.me/F5z123)

[Channel explanation](https://t.me/Source LOST)

[الاصدار الجديد ليس مجاني غير متوفر](https://t.me/z7cz9)

[لشراء احدث اصدار مع جميع المميزات راسلني](https://t.me/z7cz9)


